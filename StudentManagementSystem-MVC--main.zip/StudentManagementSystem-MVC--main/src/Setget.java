
public class Setget {

    private int id;
    private String name;

    // Constructor
    public Setget(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Setter Methods
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Getter Methods
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    // Display Method
    public void display() {
        System.out.println("ID: " + id + ", Name: " + name);
    }
}
 class SetgetMain {
    public static void main(String[] args) {
        // Create student objects using constructor
        Setget s1 = new Setget(101, "Reehu");
        Setget s2 = new Setget(102, "Sara");

        // Display original data
        s1.display();
        s2.display();

        // Modify using setters
        s1.setName("Reehana");
        s2.setId(202);

        // Display updated data using getters
        System.out.println("\nUpdated Details:");
        System.out.println("Student 1 -> ID: " + s1.getId() + ", Name: " + s1.getName());
        System.out.println("Student 2 -> ID: " + s2.getId() + ", Name: " + s2.getName());
    }
}