
public class Basic {
	int id;
	String name;
	Basic(int id,String name)
	{
		this.id=id;
		this.name=name;
		
	}
	public void display()
	{
		System.out.println("id:" +id+ ", name:" +name);
		

	}
}
class Main{
	

public static void main(String[] args)
{
	Basic b1=new Basic(101,"ABC");
	Basic b2=new Basic(102,"DEF");
	b1.display();
	b2.display();
	

}
}
